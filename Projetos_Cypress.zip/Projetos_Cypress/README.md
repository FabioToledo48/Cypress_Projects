# Projetos_Cypress
Este repositório foi criado para automatizações de testes em Cypress.
